﻿import cv2
import numpy as np
import os
import mediapipe as mp
import time

mp_holistic = mp.solutions.holistic
mp_drawing = mp.solutions.drawing_utils

def mediapipe_detection(image, model):
    try:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        image.flags.writeable = False
        results = model.process(image)
        image.flags.writeable = True
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        return image, results
    except Exception as e:
        print(f"Error in mediapipe_detection: {e}")
        return None, None

def extract_keypoints(results):
    if results is None:
        return np.zeros(1662)  # 33*4 + 468*3 + 21*3 + 21*3

    try:
        pose = np.array([[res.x, res.y, res.z, res.visibility] for res in results.pose_landmarks.landmark]).flatten() if results.pose_landmarks else np.zeros(33*4)
        face = np.array([[res.x, res.y, res.z] for res in results.face_landmarks.landmark]).flatten() if results.face_landmarks else np.zeros(468*3)
        lh = np.array([[res.x, res.y, res.z] for res in results.left_hand_landmarks.landmark]).flatten() if results.left_hand_landmarks else np.zeros(21*3)
        rh = np.array([[res.x, res.y, res.z] for res in results.right_hand_landmarks.landmark]).flatten() if results.right_hand_landmarks else np.zeros(21*3)
        return np.concatenate([pose, face, lh, rh])
    except Exception as e:
        print(f"Error in extract_keypoints: {e}")
        return np.zeros(1662)

# Path for exported data, numpy arrays
DATA_PATH = os.path.join("MP_Data")

# Actions that we try to detect
actions = np.array(["hello", "thanks", "iloveyou"])

# Test capturing one sequence
cap = cv2.VideoCapture(0)
time.sleep(1)  # Give the camera time to initialize

if not cap.isOpened():
    print("Error: Could not open camera")
    exit()

with mp_holistic.Holistic(min_detection_confidence=0.5, min_tracking_confidence=0.5) as holistic:
    print("Starting collection...")
    frames_collected = 0
    max_frames = 30
    
    while frames_collected < max_frames:
        ret, frame = cap.read()
        if not ret:
            print("Failed to grab frame")
            continue
            
        image, results = mediapipe_detection(frame, holistic)
        if image is None:
            print("Failed to process frame")
            continue
            
        cv2.putText(image, f"Collecting frame {frames_collected}/{max_frames}", (15,12), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1, cv2.LINE_AA)
        cv2.imshow("OpenCV Feed", image)
        
        keypoints = extract_keypoints(results)
        print(f"Frame {frames_collected}: Keypoints shape = {keypoints.shape}")
        
        frames_collected += 1
        
        if cv2.waitKey(10) & 0xFF == ord("q"):
            break
            
cap.release()
cv2.destroyAllWindows()

print("\nCollection completed successfully")
