﻿import cv2

def test_camera(index):
    print(f"\nTesting camera index {index}")
    cap = cv2.VideoCapture(index)
    if not cap.isOpened():
        print(f"Could not open camera {index}")
        return False
    ret, frame = cap.read()
    if ret:
        print(f"Successfully captured frame from camera {index}")
        print("Frame shape:", frame.shape)
        success = True
    else:
        print(f"Failed to capture frame from camera {index}")
        success = False
    cap.release()
    return success

# Test first 3 camera indices
for i in range(3):
    if test_camera(i):
        print(f"\nWorking camera found at index {i}")
        break
