﻿import cv2

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Could not open webcam")
else:
    print("Webcam opened successfully")
    ret, frame = cap.read()
    if ret:
        print("Successfully captured a frame")
        print("Frame shape:", frame.shape)
    else:
        print("Failed to capture frame")
    cap.release()
