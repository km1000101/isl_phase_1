﻿import cv2
import numpy as np
import mediapipe as mp
print("OpenCV version:", cv2.__version__)
print("NumPy version:", np.__version__)
print("MediaPipe version:", mp.__version__)
